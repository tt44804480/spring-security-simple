CREATE PROCEDURE containsString(IN search VARCHAR(100))
  BEGIN
	DECLARE i int default 1; 
	DECLARE size int default CHAR_LENGTH(search)-CHAR_LENGTH(REPLACE(search,',','')) + 1; -- 得出数组成员总数 
	DECLARE target_sql varchar(500) default 'select * from student where FIND_IN_SET('';

	-- 循环拼装sql
	WHILE i <= size
		DO 
			if i = size THEN
				set target_sql = CONCAT(target_sql,SUBSTRING_INDEX(SUBSTRING_INDEX(search,',',i),',',-1),'',name);');
			else 
			 set target_sql = CONCAT(target_sql,SUBSTRING_INDEX(SUBSTRING_INDEX(search,',',i),',',-1),'',name) or FIND_IN_SET('');
			end if;
		SET i = i+1; 
	END WHILE; 

 set @target_sql = target_sql;
     prepare stmt from @target_sql; 
     EXECUTE stmt;    
     deallocate prepare stmt;    
END
;
